export const products = [
  {
    "id": "pain-tee",
    "name": "Pain Anime Tee",
    "price": 299,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "image": "/images/pain.jpg",
    "stock": true
  },
  {
    "id": "geisha-tee",
    "name": "Geisha Graphic Tee",
    "price": 290,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "image": "/images/geisha.jpg",
    "stock": true
  },
  {
    "id": "badass-tee",
    "name": "Badass Girl Tee",
    "price": 279,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "image": "/images/badass.jpg",
    "stock": true
  },
  {
    "id": "freefire-kids",
    "name": "Free Fire Kid Tee",
    "price": 250,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "image": "/images/freefire.jpg",
    "stock": true
  },
  {
    "id": "black-plain",
    "name": "Plain Black Tee",
    "price": 199,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "image": "/images/plain_black.jpg",
    "stock": true
  },
  {
    "id": "marvel-red",
    "name": "Marvel Red Tee",
    "price": 275,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "image": "/images/marvel_red.jpg",
    "stock": true
  },
  {
    "id": "marvel-black",
    "name": "Marvel Black Tee",
    "price": 289,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "image": "/images/marvel_black.jpg",
    "stock": true
  },
  {
    "id": "stickers-tee",
    "name": "Sticker Print Tee",
    "price": 249,
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "image": "/images/stickers.jpg",
    "stock": true
  }
];